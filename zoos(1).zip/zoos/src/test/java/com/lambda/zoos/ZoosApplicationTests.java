package com.lambda.zoos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZoosApplicationTests {

	@Test
	void contextLoads() {
	}

}
