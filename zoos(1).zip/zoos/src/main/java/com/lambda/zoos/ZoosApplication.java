package com.lambda.zoos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZoosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZoosApplication.class, args);
	}

}
